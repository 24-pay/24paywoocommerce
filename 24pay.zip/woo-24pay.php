<?php
/*
Plugin Name: Woocommerce 24pay Payment gateway
Plugin URI: http://www.24-pay.sk
Description: 24pay Payment Gateway for WooCommerce e-shop.
Author: 24pay
Version: 1.1.3
Author URI: https://www.24-pay.sk
License: MIT
*/
 
defined( 'ABSPATH' ) or exit;

define( 'PLUGIN_PATH_24PAY', plugin_dir_path( __FILE__ ) );

require_once( PLUGIN_PATH_24PAY . 'woo-24pay-signgenerator.php' );
require_once( PLUGIN_PATH_24PAY . 'woo-24pay-datavalidator.php' );
require_once( PLUGIN_PATH_24PAY . 'woo-24pay-formbuilder.php' );
require_once( PLUGIN_PATH_24PAY . 'woo-24pay-nurlparser.php' );
require_once( PLUGIN_PATH_24PAY . 'woo-24pay-orderresolver.php' );

// Make sure WooCommerce is active
if ( ! in_array( 'woocommerce/woocommerce.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) {
	return;
}


function woo_24pay_add_to_gateways( $gateways ) {
	$gateways[] = 'Woo_24pay_Gateway';
	return $gateways;
}
add_filter( 'woocommerce_payment_gateways', 'woo_24pay_add_to_gateways' );

function woo_24pay_gateway_plugin_links( $links ) {

	$plugin_links = array(
		'<a href="' . admin_url( 'admin.php?page=wc-settings&tab=checkout&section=24pay_gateway' ) . '">' . __( 'Configure', 'wc-gateway-offline' ) . '</a>'
	);

	return array_merge( $plugin_links, $links );
}

add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), 'woo_24pay_gateway_plugin_links' );

add_action( 'plugins_loaded', 'woo_24pay_gateway_init', 11 );

add_action('before_woocommerce_init', function(){
    if ( class_exists( \Automattic\WooCommerce\Utilities\FeaturesUtil::class ) ) {
        \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables', __FILE__, true );
    }
});

function woo_24pay_gateway_init() {

	class Woo_24pay_Gateway extends WC_Payment_Gateway {

		/**
		 * Constructor for the gateway.
		 */
		public function __construct() {
	  
			$this->id                 = '24pay_gateway';
			$this->icon = plugins_url('', __FILE__).'/logos/24pay-icon.png';
			$this->has_fields         = false;
			$this->method_title       = '24pay_gateway';
			$this->method_description = 'Payment gateway 24-pay description.';
		  
			// Load the settings.
			$this->init_form_fields();
			$this->init_settings();
		  
			// Define user set variables
			$this->title        = $this->get_option( 'title' );
			$this->description  = $this->get_option( 'description' );
//			$this->instructions = $this->get_option( 'instructions', $this->description );
		  
			// Actions
			add_action('woocommerce_update_options_payment_gateways_' . $this->id, array( $this, 'process_admin_options' ) );
			add_action('woocommerce_receipt_24pay_gateway', array($this, 'payment_form'));
		}

		public function init_form_fields() {
	  
			$this->form_fields = apply_filters( 'woo_24pay_gateway_form_fields', array(
		  
				'enabled' => array(
					'title'   => 'Enable/Disable',
					'type'    => 'checkbox',
					'label'   => 'Enable 24-pay',
					'default' => 'yes'
				),
				
				'title' => array(
				  'title' => 'Title',
				  'type' => 'text',
				  'description' => 'This controls the title which the user sees during checkout.',
				  'default' => '24-pay | Platobná brána',
				),
				
				'description' => array(
				  'title' => 'Method description',
				  'type' => 'textarea',
				  'description' => 'Method description when selected during checkout.',
				  'default' => 'Zaplaťte bezpečne s vašou kreditnou kartou alebo bankovým prevodom pomocou služby 24pay.',
				),
				
				'is_test' => array(
				  'title' => 'Test mode',
				  'type' => 'checkbox',
				  'label' => 'Make payment on test environment (Use only during development!)',
				  'default' => 'yes',
				),
				
				'mid' => array(
					'title'       => 'Mid',
					'type'        => 'text',
					'description' => 'This parameter was send to you via SMS after contract sing.',
					'default'     => 'demoOMED',
					'desc_tip'    => true,
				),
				
				'key' => array(
					'title'       => 'Key',
					'type'        => 'text',
					'description' => 'This parameter was send to you via SMS after contract sing.',
					'default'     => '1234567812345678123456781234567812345678123456781234567812345678',
					'desc_tip'    => true,
				),

                'eshop' => array(
                    'title'       => 'EUR EshopId',
                    'type'        => 'text',
                    'description' => 'This parameter was send to you via SMS after contract sing.',
                    'default'     => '11111111',
                    'desc_tip'    => true,
                ),

                'eshop_czk' => array(
                    'title'       => 'CZK EshopId',
                    'type'        => 'text',
                    'description' => 'This parameter was send to you via SMS after contract sing.',
                    'default'     => '33333333',
                    'desc_tip'    => true,
                ),

                'eshop_pln' => array(
                    'title'       => 'PLN EshopId',
                    'type'        => 'text',
                    'description' => 'This parameter was send to you via SMS after contract sing.',
                    'default'     => '11111111',
                    'desc_tip'    => true,
                ),

                'eshop_huf' => array(
                    'title'       => 'HUF EshopId',
                    'type'        => 'text',
                    'description' => 'This parameter was send to you via SMS after contract sing.',
                    'default'     => '66666666',
                    'desc_tip'    => true,
                ),

                'rurl' => array(
                    'title' => 'EUR RURL',
                    'type' => 'text',
                    'description' => 'Specify url to which customer will be redirected after payment.',
                    'default' => get_site_url().'/24pay-rurl/',
                ),

                'rurl_czk' => array(
                    'title' => 'CZK RURL',
                    'type' => 'text',
                    'description' => 'Specify url to which customer will be redirected after payment (CZK).',
                    'default' => get_site_url().'/24pay-rurl/',
                ),

                'rurl_pln' => array(
                    'title' => 'PLN RURL',
                    'type' => 'text',
                    'description' => 'Specify url to which customer will be redirected after payment (PLN).',
                    'default' => get_site_url().'/24pay-rurl/',
                ),

                'rurl_huf' => array(
                    'title' => 'HUF RURL',
                    'type' => 'text',
                    'description' => 'Specify url to which customer will be redirected after payment (HUF).',
                    'default' => get_site_url().'/24pay-rurl/',
                ),

                'nurl' => array(
                    'title' => 'NURL',
                    'type' => 'text',
                    'description' => 'Specify url to which you will receive notification message.',
                    'default' => get_site_url().'/24pay-nurl/',
                ),

				'notify_email' => array(
				  'title' => 'Notify Email (optional)',
				  'type' => 'text',
				  'description' => 'Set email where you want receive notification ater payment.',
				  'default' => '',
				),

				'notify_client' => array(
					'title'   => 'Notify client by email',
					'type'    => 'checkbox',
					'label'   => 'Send payment status email to client',
					'default' => 'no'
				),

                'save_transaction_email' => array(
                    'title'   => 'Save transaction email',
                    'type'    => 'checkbox',
                    'label'   => 'Send offline payment link in case of no response or declined payment.',
                    'default' => 'no'
                ),

                'enable_logs' => array(
                    'title'   => 'Enable/Disable logs',
                    'type'    => 'checkbox',
                    'label'   => 'Enable 24-pay logs',
                    'default' => 'no'
                ),

                'language' => array(
                    'title' => 'Language',
                    'description' => 'If you choose specific language, the payment will always be displayed in this language!',
                    'type' => 'select',
                    'options' => array(
                        "auto"=>"automatically (based on the language in the order)",
                        "sk"=>"Slovenčina",
                        "cz"=>"Čeština",
                        "en"=>"English",
                        "de"=>"Deutch",
                        "fr"=>"Français",
                        "it"=>"Italiano",
                        "pl"=>"Polski",
                        "hu"=>"Magyar",
                        "es"=>"Español",
                        "ro"=>"Română",
                        "sl"=>"Slovenščina",
                    ),
                    'default' => 'auto'
                ),

                'cart' => array(
                    'title'   => 'Include cart & shipping',
                    'type'    => 'checkbox',
                    'label'   => 'Required only for the pay later payment method.',
                    'default' => 'no'
                ),
				
			) );
		}

		public function thankyou_page() {
			if ( $this->instructions ) {
				echo wpautop( wptexturize( $this->instructions ) );
			}
		}

		function process_payment($order_id)
	    {
	      $order = wc_get_order($order_id);
	      $redirect_url = add_query_arg('key', $order->get_order_key(), $order->get_checkout_payment_url(true));

	      return array(
	        'result'    => 'success',
	        'redirect'  => $redirect_url
	      );
	    }
	
		function payment_form($order_id)
	    {
	      $order = wc_get_order($order_id);

	      $is_test = (!empty($this->settings['is_test']) && $this->settings['is_test']=='yes') ? true : false;
		  $notify_client = (!empty($this->settings['notify_client']) && $this->settings['notify_client']=='yes') ? true : false;
		  $save_transaction_email = (!empty($this->settings['save_transaction_email']) && $this->settings['save_transaction_email']=='yes') ? true : false;
		  $cart = (!empty($this->settings['cart']) && $this->settings['cart']=='yes') ? true : false;

//	      $language = 'SK';
	      $language = $this->get_current_lang_code();
	      $country = 'SVK';

	      $data = array(
	        'Mid' => $this->settings['mid'],
            'EshopId' => $this->get_eshop_id_by_currency(),
	        'MsTxnId' => $order->get_order_number(),
	        // Use option below if 3rd party order number plugin is used withou order load support in method load_order_by_mstxnid
		//'MsTxnId' => $order->get_id(), 
	        'Amount' => number_format($order->get_total(), 2, '.', ''),
	        'CurrAlphaCode' => get_woocommerce_currency(),
	        'ClientId' => str_pad($order->get_order_number(),3,"0",STR_PAD_LEFT),
	        'FirstName' => $order->get_billing_first_name(),
	        'FamilyName' => $order->get_billing_last_name(),
	        'Email' => $order->get_billing_email(),
	        'Country' => $country,
	        'Timestamp' => date("Y-m-d H:i:s"),
	        'LangCode' => $language,
	        'RedirectSign' => 'true',
	        'RURL' => $this->get_rurl_by_currency(),
	        'NURL' => $this->settings['nurl'],
	        'Debug' => 'true',
	      );

	      $signGenerator = new WOO_24pay_SignGenerator($data, $this->settings['key']);
	      $data['Sign'] = $signGenerator->sign();

 		  if (!empty($this->settings['notify_email']))
 		  	$data['NotifyEmail'] = $this->settings['notify_email'];
		  
		  if ($is_test)
			$data['url'] = 'https://test.24-pay.eu/pay_gate/paygt';
		  else
			$data['url'] = 'https://admin.24-pay.eu/pay_gate/paygt';

		  if ($notify_client)
			$data['NotifyClient'] = $order->get_billing_email();

          if ($save_transaction_email)
              $data['SaveTransactionEmail'] = $order->get_billing_email();

          if ($cart)
              $data['Cart'] = $this->get_cart_json_base64($order);

		  $dataValidator = new WOO_24pay_DataValidator();

		  if ($dataValidator->validate($data)){
		  	$formBuilder = new WOO_24pay_FormBuilder();
		  	echo $formBuilder->build($data);
		  	die();
		  }
		  else{
			echo $dataValidator->renderErrors();
			die();
		  }

		}

        public function get_eshop_id_by_currency(){
            $currAlphaCode = strtolower(get_woocommerce_currency());
            $eshopIdSuffixConf = array(
                'eur' => '',
                'czk' => '_czk',
                'pln' => '_pln',
                'huf' => '_huf'
            );

            if(array_key_exists($currAlphaCode, $eshopIdSuffixConf)){
                $suffix = $eshopIdSuffixConf[$currAlphaCode];
                return $this->settings['eshop' . $suffix];
            }

            // fallback if an unsupported currency slips through
            $this->write_log("Unsupported currency for EshopId lookup: " . $currAlphaCode);
            return $this->settings['eshop'];
        }

        public function get_rurl_by_currency(){
            $currAlphaCode = strtolower(get_woocommerce_currency());
            $rurlSuffixConf = array(
                'eur' => '',
                'czk' => '_czk',
                'pln' => '_pln',
                'huf' => '_huf'
            );

            if(array_key_exists($currAlphaCode, $rurlSuffixConf)){
                $suffix = $rurlSuffixConf[$currAlphaCode];
                $rurlKey = 'rurl' . $suffix;
                if (!empty($this->settings[$rurlKey])) {
                    return $this->settings[$rurlKey];
                }
            } else {
                $this->write_log("Unsupported currency for RURL lookup: " . $currAlphaCode);
            }

            if (!empty($this->settings['rurl'])) {
                return $this->settings['rurl'];
            }

            return get_site_url().'/24pay-rurl/';
        }

        function get_cart_json_base64( $order ) {
            if ( ! $order || ! is_a( $order, 'WC_Order' ) ) {
                return null;
            }

            $shipping_methods = $order->get_shipping_methods();
            $deliveryName  = '';
            $deliveryPrice = 0;

            if ( ! empty( $shipping_methods ) ) {
                $shipping_method = array_shift( $shipping_methods );
                $deliveryName  = $shipping_method->get_name();
                $deliveryPrice = $shipping_method->get_total();
            }

            $items = [];
            foreach ( $order->get_items() as $item ) {
                $product = $item->get_product();

                $items[] = [
                    'itemName'        => $item->get_name(),
                    'itemDescription' => $product ? $product->get_short_description() : '',
                    'quantity'        => $item->get_quantity(),
                    'itemPrice'       => number_format( $item->get_total() / max(1, $item->get_quantity()), 2, '.', ''),
                ];
            }

            $data = [
                'deliveryName'  => $deliveryName,
                'deliveryPrice' => number_format( $deliveryPrice, 2, '.', '' ),
                'items'         => $items,
            ];

            return base64_encode( json_encode($data, JSON_UNESCAPED_UNICODE) );
        }

        public function get_current_lang_code(){
            if(!empty($this->settings['language']) && $this->settings['language'] != "auto") {
                return $this->settings['language'];
            }
            $supported_lang_codes = array("cs", "de", "en", "es", "fr", "hu", "it", "pl", "ro", "sk");
            $lang = get_bloginfo('language');
            $lang_code = explode("-", $lang);
            if(!$lang_code) {
                return "en";
            }
            return in_array($lang_code[0], $supported_lang_codes) ? $lang_code[0] : "en";
        }
	    public function load_order_by_mstxnid( $order_id )
	    {
	        $resolved_id = Order_Number_Resolver::resolve( $order_id );
	        return $resolved_id ? wc_get_order( $resolved_id ) : false;
	    }

		public function process_rurl($msTxnId){
			$order = $this->load_order_by_mstxnid($msTxnId);

			$redirectTarget = home_url();

			if($order!= false)
      		{
                $order->add_order_note("Client was successfully redirected");

      			$signGenerator = new WOO_24pay_SignGenerator(array('Mid'=>$this->settings['mid']), $this->settings['key']);
      			$message = $_GET['MsTxnId'].$_GET['Amount'].$_GET['CurrCode'].$_GET['Result'];
      			if ($signGenerator->sign($message) == $_GET['Sign']){
      				$redirectTarget = $this->get_return_url($order);
      			}
      			else{
      				wc_add_notice('INVALID REDIRECT SIGN!', 'error');
      			}
      		}
            else {
                $this->write_log("Unable to get Order ID! for "  . $msTxnId);
            }
            $this->write_log("RURL: " . $redirectTarget);
      		wp_safe_redirect($redirectTarget);
        	die();
		}		

		public function process_nurl($xml)
    	{
          $this->write_log($xml);
	      $notification = new WOO_24pay_NurlParser($xml, $this->settings['mid'], $this->settings['key']);
	      if ($notification->parsed){
	      	if ($notification->validateSign()){
	      		
	      		$order = $this->load_order_by_mstxnid($notification->msTxnId);
	      		
	      		/* OK - FAIL - PENDING */
	      		
	      		if($notification->result == 'OK')
		        {
                    $this->write_log("Notification message received with Success result");

		        	$order->add_order_note("Notification message received with Success result");
		        	$order->payment_complete();
		        }
		        else if($notification->result == 'PENDING')
		        {
                    		$this->write_log("Notification message received with Pending result");

		        	$order->add_order_note("Notification message received with Pending result");
		        	$order->update_status('on-hold', '24-pay payment is pending. Payment status will be processed with next notification message.');
		        }
			    else if($notification->result == 'AUTHORIZED')
		        {
                    		$this->write_log("Notification message received with AUTHORIZED result");

		        	$order->add_order_note("Notification message received with AUTHORIZED result");
		        	$order->update_status('on-hold', '24-pay payment is AUTHORIZED. Payment status will be processed by your action.');
		        }
                else if($notification->result == 'REVERSAL')
                {
                    $this->write_log("Notification message received with REVERSAL result");

                    $order->add_order_note("Notification message received with REVERSAL result");
                    $order->update_status('refunded', '24-pay payment is REVERSAL.');
                }
		        else
		        {
                    $this->write_log("Notification message received with Fail result");

		        	$order->add_order_note("Notification message received with Fail result");
		        	$order->update_status('failed', '24-pay payment failed.');
		        }
		        
		        return true;
	      	}
	      }
	      return false;
	    }

        function write_log($log) {
            if((!empty($this->settings['enable_logs'])) && $this->settings['enable_logs']=='yes') {
                $logfile = fopen(PLUGIN_PATH_24PAY . "log.txt", "a") or die("Unable to open file!");

                if (is_array($log) || is_object($log)) {
                    fwrite($logfile, "[" . date("Y-m-d H:i:s") . "] => " . print_r($log, true) . "\n");
                } else {
                    fwrite($logfile, "[" . date("Y-m-d H:i:s") . "] => " . $log . "\n");
                }
                fclose($logfile);
            }
        }
		
	  }
  
	  add_action('init', 'listener_24pay');
	  function listener_24pay()
	  {
		$fullUrl = get_site_url().$_SERVER['REQUEST_URI'];
		$httpsUrl="https://".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
		$httpUrl="http://".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI']; 
		
		$gateway = new Woo_24pay_Gateway();
	    if(isset($_GET['MsTxnId']) && isset($_GET['Result'])) // RURL
	    {
      		$gateway->process_rurl($_GET['MsTxnId']);
	    }
	    else if(isset($_POST['params'])) // NURL
	    {	
	    	if (($httpsUrl == $gateway->settings['nurl']) || ($httpUrl == $gateway->settings['nurl']) || ($fullUrl == $gateway->settings['nurl'])){
		    	if(!$gateway->process_nurl($_POST['params']))
		        	echo 'FAIL';
		    	else{
		    		echo 'OK';
				http_response_code(200);
				die();
			};
	    	}
		else{
			//echo "URL MISMATCH <br/>";
			//echo "LISTENING ON: ".$gateway->settings['nurl']. "<br/>";
			//echo "HTTPS: ".$httpsUrl. "<br/>";
			//echo "HTTP: ".$httpUrl. "<br/>";
			//echo "FULL: ".$fullUrl. "<br/>";
		}

	    	//die();
	    }
	  }
}
